﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lp2_Trab
{
    class TsunamiControlo
    {
        #region inicia tsunamis
        DadosTsunami TsunamiControl = new DadosTsunami();

        #endregion

        #region Methods
        public bool CreateTsunami(Tsunami tsu)
        {
            bool res = false;
            try
            {
                res = TsunamiControl.CreateTsunami(tsu); ;
            }
            catch (Exception e) { throw e; }
            return false;
        }
        public List<Tsunami> ListAllTsunamis()
        {
            return TsunamiControl.TsunamiList();
        }
        public string NameById(int pp)
        {
            List<Tsunami> aux = TsunamiControl.TsunamiList();

            foreach (Tsunami item in aux)
                if (item.TotalVitimas == pp) return item.Name;
            return ("Not found");
        }
        bool ExistTsunami(Tsunami tsu)
        {
            if (TsunamiControl.TsunamiList().Contains(tsu) == false) { return false; }
            else { return true; }
        }
        public bool DeleteTsunami(Tsunami tsu)
        {
            if (ExistTsunami(tsu) == false) { throw new Exception("No Tsunami!"); }
            else
            {
                try { DeleteTsunami(tsu); } catch (Exception problem) { throw problem; }
                return true;
            }
        }
        public bool DeleteTsunamiById(int id)
        {
            try
            {
                TsunamiControl.RemoveTsunamibyID(id);
            }
            catch (Exception e) { Console.WriteLine("Fodeu:" + e.Message); }
            return true;
        }
        /// <summary>
        /// numero de tsunamis
        /// </summary>
        /// <returns></returns>
        public int NumberOfTsunamis()
        {
            return TsunamiControl.Count();
        }
        public bool Save(string fileName)
        {
            // write the data to a file
            try
            {
                TsunamiControl.Save(fileName);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return true;
        }
        public bool Load(string fileName)
        {
            try
            {
                TsunamiControl.Load(fileName);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return true;
        }
        #endregion
    }
}
