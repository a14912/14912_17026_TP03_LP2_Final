﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lp2_Trab
{

    public enum tipo
    {
        tsunami,
        incendio
    }
    
    [Serializable]
    public class Catastrofe
    {
        //atributos
        #region atribute
        int id;
        string name;
        tipo tipo;
        #endregion

        #region Constructors
        //Construtor com todos os campos
        public Catastrofe(int i, string n, tipo s)
        {
            id = i;
            name = n;
            tipo = s;
        }
        //Construtor vazio
        public Catastrofe()
        {
            this.id = 0;
            this.name = null;
            this.tipo = 0;
        }

        #endregion
        //properties para edição dos valores
        #region Properties
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public int Id
        {
            get { return id; }
            set { id = value; }
        }
        public tipo Tipo
        {
            get { return tipo; }
            set { tipo = value; }
        }

        #endregion

    }
}
