﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Text;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Linq;

namespace Lp2_Trab
{
    class DadosTsunami
    {
        #region Lista para todos tsunamis
        private List<Tsunami> tsuList;
        #endregion

        #region Constructs
        public DadosTsunami()
        {
            this.tsuList = new List<Tsunami>();
        }
        #endregion

        #region Methods

        public bool CreateTsunami(Tsunami tsu)
        {
            if (ExistTsunami(tsu) == false)
            {
                int aux = tsuList.Count;
                try
                {
                    tsuList.Add(tsu);
                }
                catch (Exception e) { throw new Exception(e.Message); }
                if (aux == tsuList.Count) { return true; } else { throw new Exception("Erro"); }
            }
            else { throw new Exception("Tsunami ja existe"); }

        }
        public List<Tsunami> TsunamiList()
        {
            return tsuList;
        }
        bool ExistTsunami(Tsunami tsu)
        {
            if (tsuList.Contains(tsu) == false) { return false; } else { return true; }
        }
        public bool DeleteTsunami(Tsunami tsu, Exception e)
        {
            if (ExistTsunami(tsu) == false) { return false; throw new Exception("No tsunami"); }
            else
            {
                try
                {
                    tsuList.Remove(tsu);
                }
                catch (Exception problem) { throw problem; }

                return true;
            }
        }
        public bool RemoveTsunamibyID(int id)
        {
            Tsunami aux = tsuList.Find(item => item.Id == id); //1st lambda expression :) 
            //Console.WriteLine("{0},{1},{2}", aux.Id, aux.Name, aux.Tipo);
            if (aux.Id == null) { return false; throw new Exception("No Tsunami"); }
            else
            {
                try
                {
                  
                    tsuList.Remove(aux);
                }
                catch (Exception problem) { throw problem; }

                return true;
            }
        }
        public int Count()
        {
            return tsuList.Count();

        }

        /// <summary>
        /// metodo para guardar os dados tsunami em bin
        /// </summary>
        /// <param name="fileName">nome do ficheiro</param>
        /// <returns>true or false</returns>
        public bool Save(string fileName)
        {
            // write the data to a file
            var binformatter = new BinaryFormatter();
            try
            {
                Stream s = File.Open(fileName, FileMode.Create, FileAccess.ReadWrite);
                BinaryFormatter b = new BinaryFormatter();
                b.Serialize(s, tsuList);
                s.Close();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return true;
        }
        public bool Load(string fileName)
        {
            //Hashtable aux = null;
            Stream s = File.Open(fileName, FileMode.Open, FileAccess.Read);
            BinaryFormatter b = new BinaryFormatter();
            tsuList = (List<Tsunami>)b.Deserialize(s);
            s.Close();
            return true;
        }


        #endregion


    }
}
