﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lp2_Trab
{
    [Serializable]
    class ControloTabela
    {
        #region ATIBUTES

        private List<TabelaC> tabelas;
        const int nTabelas = 10;


        #endregion

        #region CONSTRUTORES

        /// <summary>
        /// lista de catastrofes
        /// </summary>
        public ControloTabela()
        {
            this.tabelas = new List<TabelaC>();
        }

        #endregion

        #region PROPERTIES


        public List<TabelaC> Alltabelas
        {
            get { return tabelas; }
            set { tabelas = value; }
        }

        public static int NTabelas
        {
            get { return nTabelas; }
        }

        #endregion

        #region METODOS



        #endregion
    }
}
