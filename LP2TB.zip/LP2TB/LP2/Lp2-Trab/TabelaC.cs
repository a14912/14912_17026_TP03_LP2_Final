﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace Lp2_Trab
{
    public enum Risco
    {
        alto,
        baixo,
        medio
    }

    [Serializable]
    public class TabelaC
    {
        #region Atributos

        
        
        int catastrofeId;
        const int nCatastrofes = 100;
        string tipo;
        List<int> tsunamiID = new List<int>();
        List<int> incendioId = new List<int>();
        DateTime data;
        Risco risco;

        #endregion

        #region Constructors
        /// <summary>
        /// criar nova catastrofe
        /// </summary>
        /// <param name="id">identificacao da catastrofe</param>
        /// <param name="tipo">rupo catastrofe</param>
        public TabelaC(int id, string tipo, string s, Risco rs)
        {
            DateTime date;

            this.catastrofeId = id;
            this.tipo = tipo;
            this.tsunamiID = new List<int>();
            this.incendioId = new List<int>();
            if (DateVerification(s, out date) == true) this.data = date;
            this.risco = rs;

        }
        /// <summary>
        /// Valor vazio
        /// </summary>
        public TabelaC()
        {
            this.catastrofeId = -1;
            this.tipo = null;
            this.incendioId = null;
            this.tsunamiID = null;
            this.data = DateTime.Now;
            this.risco = Risco.medio;
        }

        #endregion

        #region METODOS

        /// <summary>
        /// Verificar se data é valida
        /// </summary>
        /// <param name="s">string a verificar</param>
        /// <param name="d">out data</param>
        /// <returns>true or false</returns>
        public bool DateVerification(string s, out DateTime d)
        {

            if (DateTime.TryParse(s, out d))
                return true;
            else
                return false;
        }

        #endregion

        #region PROPERTIES

        /// <summary>
        /// ID catastrofe
        /// </summary>
        public int CatastrofeID
        {
            get { return catastrofeId; }
            set { catastrofeId = value; }
        }

        public static int NCatastrofes
        {
            get { return nCatastrofes; }
        }

        public List<int> TsunamiID
        {
            get { return tsunamiID; }
        }

        public List<int> IncendioId
        {
            get { return incendioId; }
        }

        public Risco Risco
        {
            get { return risco; }
            set { risco = value; }
        }
        /// <summary>
        /// tipo catastrofe
        /// </summary>
        public string Tipo
        {
            get { return tipo; }
            set { tipo = value; }
        }


        #endregion

        #region OVERRIDES

        public override string ToString()
        {
            return "ID: " + this.catastrofeId + ", Tipo: " + this.tipo + ", Data: " + this.data.ToShortDateString() + ", Risco: " + this.risco;
        }


        #endregion



    }
}
