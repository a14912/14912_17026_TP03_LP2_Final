﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lp2_Trab
{
    public enum Grau
    {
        perigoso,
        seguro,
        medio
    };

    [Serializable]
     public class Tsunami : Catastrofe
    {
        #region Atributos

        string epicentro;
        int totalvitimas;
        //Grau grau;
        #endregion

        #region Properties
        public int TotalVitimas
        {
            get { return totalvitimas; }
            set { totalvitimas = value; }
        }
        public string Epicentro
        {
            get { return epicentro; }
            set { epicentro = value; }
        }

       
        #endregion

        #region Contructs
        /// <summary>
        /// ID, Nome, Risco, TotalVitimas, Epicentro
        /// </summary>
        /// <param name="i"></param>
        /// <param name="n"></param>
        /// <param name="s"></param>
        /// <param name="p">TotalVitimas</param>
        public Tsunami(int i, string n, tipo tp, int tv, string ep)
        {
            this.Id = i;
            this.Name = n;
            this.Tipo = tp;
            this.totalvitimas = tv;
            this.epicentro = ep;
        }
        public Tsunami()
        {
            this.Id = 0;
            this.Name = null;
            this.Tipo = 0;
            this.totalvitimas = 0;
            this.epicentro = null;
        }
        public Tsunami(int i, string n, tipo tp)
        {
            this.Id = i;
            this.Name = n;
            this.Tipo = tp;
            this.totalvitimas = 0;
            this.epicentro = null;
        }
        #endregion

        #region OVERRIDES
        public override string ToString()
        {
            return "Identificacao Tsunami:" + this.Id + " Nome:" + this.Name;
        }

        public override bool Equals(object obj)
        {
            Tsunami aux = (Tsunami)obj;
            return ((this.Id == aux.Id) ? true : false);
        }
        public static bool operator ==(Tsunami x, Tsunami y)
        {
            return (x.Equals(y));
        }
        public static bool operator !=(Tsunami x, Tsunami y)
        {
            return (!(x == y));
        }
        #endregion

    }
}