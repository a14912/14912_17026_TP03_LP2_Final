﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lp2_Trab
{
    interface Interfaces
    {
        interface IIncendioControl
        {
            bool AddIncendio(Incendio i);
            List<Incendio> ListAllIncendios();
            bool CreateIncendio(Incendio i);
            string NameByID(int id);
            bool ExistIncendio(Incendio i);
            bool DeleteIncendio(Incendio i);
            bool DeleteIncendioById(int i);
            bool Save(string path);
            bool Load(string path);


        }

        interface IDadosIncendio
        {



            bool CreateIncendio(Incendio i);
            List<Incendio> IncendioList();
            bool ExistIncendio(Incendio i);
            bool DeleteIncendio(Incendio i);
            bool DeleteIncendioById(int i);
            int Count();
            bool Save(string path);
            bool Load(string path);

        }

        interface ITsunamiControl
        {
            bool AddTsunami(Tsunami tsu);
            List<Incendio> ListAllTsunamis();
            bool CreateTsunami(Tsunami tsu);
            string NameByID(int id);
            bool ExistTsunami(Tsunami tsu);
            bool DeleteTsunami(Tsunami tsu);
            bool DeleteTsunamiById(int id);
            bool Save(string path);
            bool Load(string path);


        }

        interface IDadosTsunami
        {



            bool CreateTsunami(Tsunami tsu);
            List<Tsunami> TsunamiList();
            bool ExistTsunami(Tsunami i);
            bool DeleteTsunami(Tsunami i);
            bool DeleteTsunamiById(int id);
            int Count();
            bool Save(string path);
            bool Load(string path);

        }


    }
}
