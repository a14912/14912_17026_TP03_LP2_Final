﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.Serialization.Formatters.Binary;
using System.Linq;
using System.Text;

namespace Lp2_Trab
{
    /// <summary>
    /// Incendio herda de Catrastrofe
    /// </summary
    
    public enum Status
    {
        ativo,
        extinto
    }
    [Serializable]
    public class Incendio : Catastrofe
    {
        #region Atributos
        string local;
        int area;
        int duracao;
        Status status;
        
        #endregion

        #region Properties
        public int Area
        {
            get { return area; }
            set { area = value; }
        }
        public string Local
        {
            get { return local; }
            set { local = value; }
        }

        public int Duracao
        {
            get { return duracao; }
            set { duracao = value; }
        }

        public Status Status
        {
            get { return Status; }
            set { status = value; }
        }

        #endregion

        #region Contructs
        /// <summary>
        /// ID, Nome, Risco, TotalVitimas, Epicentro
        /// </summary>
        /// <param name="i"></param>
        /// <param name="n"></param>
        /// <param name="s"></param>
        /// <param name="p">TotalVitimas</param>
        public Incendio(int i, string n, tipo tp, int ar, int dur, string loc, Status st)
        {
            this.Id = i;
            this.Name = n;
            this.Tipo = tp;
            this.area = ar;
            this.duracao = dur;
            this.local = loc;
            this.Status = Status.extinto;
        }
        public Incendio()
        {
            this.Id = 0;
            this.Name = null;
            this.Tipo = 0;
            this.duracao = 0;
            this.area =0;
            this.local = null;
            this.Status = 0;
        }
        public Incendio(int i, string n, tipo tp)
        {
            this.Id = i;
            this.Name = n;
            this.Tipo = tp;
            this.duracao = 0;
            this.local = null;
            this.area = 0;
            this.Status = Status.extinto;
        }
        #endregion

        #region OVERRIDES
        public override string ToString()
        {
            return "Identificacao Incendio:" + this.Id + " Nome:" + this.Name;
        }

        public override bool Equals(object obj)
        {
            Tsunami aux = (Tsunami)obj;
            return ((this.Id == aux.Id) ? true : false);
        }
        public static bool operator ==(Incendio x, Incendio y)
        {
            return (x.Equals(y));
        }
        public static bool operator !=(Incendio x, Incendio y)
        {
            return (!(x == y));
        }
        #endregion

    }


}

